package minesweeper.core;

/**
 * Mine tile.
 */
public class Mine extends Tile {
}
